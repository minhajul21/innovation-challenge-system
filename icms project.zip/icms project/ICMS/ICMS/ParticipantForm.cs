﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class ParticipantForm : Form
    {
        private Panel contentPanel;
        private Panel sidebar;
        private Button activeBtn;

        public ParticipantForm()
        {
            this.Text = "ICMS Participant";
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.MinimumSize = new Size(1200, 720);

            // 1. Content panel FIRST (Dock=Fill) - docks last
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(241, 245, 249),
                AutoScroll = true,
                Padding = new Padding(30)
            };

            // 2. Main area (right of sidebar) - contains topbar + content
            var mainArea = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(241, 245, 249)
            };

            // 3. Top bar
            var topBar = BuildTopBar();

            // 4. Sidebar (Left)
            sidebar = BuildSidebar();

            // Add in proper order for docking
            mainArea.Controls.Add(contentPanel);   // Fill
            mainArea.Controls.Add(topBar);         // Top

            this.Controls.Add(mainArea);           // Fill
            this.Controls.Add(sidebar);            // Left (added last, docks first)

            // Load default
            this.Load += (s, e) =>
            {
                var btn = (Button)sidebar.Controls["btnOverview"];
                if (btn != null) SidebarBtn_Click(btn, EventArgs.Empty);
            };
        }

        private Panel BuildSidebar()
        {
            var s = new Panel
            {
                Dock = DockStyle.Left,
                Width = 240,
                BackColor = Color.FromArgb(15, 23, 42)
            };

            s.Controls.Add(new Label
            {
                Text = "◈  ICMS\n     Participant",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 25),
                Size = new Size(220, 70)
            });

            string[] items = { "Overview", "Available Challenges", "My Submissions" };
            string[] icons = { "▦", "★", "⇧" };
            int y = 130;

            for (int i = 0; i < items.Length; i++)
            {
                var btn = new Button
                {
                    Name = "btn" + items[i].Replace(" ", ""),
                    Text = "   " + icons[i] + "   " + items[i],
                    Location = new Point(0, y),
                    Size = new Size(240, 45),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(15, 23, 42),
                    ForeColor = Color.FromArgb(203, 213, 225),
                    Font = new Font("Segoe UI", 10),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Cursor = Cursors.Hand
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 41, 59);
                btn.Click += SidebarBtn_Click;
                s.Controls.Add(btn);
                y += 48;
            }

            // Logout at bottom
            var btnLogout = new Button
            {
                Text = "   ⏻   Logout",
                Location = new Point(0, 620),
                Size = new Size(240, 45),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(15, 23, 42),
                ForeColor = Color.FromArgb(248, 113, 113),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatAppearance.MouseOverBackColor = Color.FromArgb(60, 20, 30);
            btnLogout.Click += (s2, e2) =>
            {
                if (MessageBox.Show("Are you sure you want to log out?", "Logout",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    this.Close();
            };
            s.Controls.Add(btnLogout);

            return s;
        }

        private Panel BuildTopBar()
        {
            var topBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = Color.White
            };

            topBar.Controls.Add(new Label
            {
                Text = "Participant Dashboard",
                Font = new Font("Segoe UI", 13, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(25, 20),
                AutoSize = true
            });

            var lblUser = new Label
            {
                Text = Session.DisplayName + " · Participant",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleRight,
                Location = new Point(topBar.Width - 400, 22),
                Size = new Size(260, 25),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                ForeColor = Color.FromArgb(30, 41, 59)
            };
            topBar.Controls.Add(lblUser);

            var btnLogout = new Button
            {
                Text = "Logout",
                Size = new Size(95, 36),
                Location = new Point(topBar.Width - 120, 15),
                BackColor = Color.FromArgb(254, 242, 242),
                ForeColor = Color.FromArgb(220, 38, 38),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += (s, e) =>
            {
                if (MessageBox.Show("Are you sure you want to log out?", "Logout",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    this.Close();
            };
            topBar.Controls.Add(btnLogout);

            return topBar;
        }

        private void SidebarBtn_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            string name = btn.Name.Substring(3);

            // Highlight active
            if (activeBtn != null)
            {
                activeBtn.BackColor = Color.FromArgb(15, 23, 42);
                activeBtn.ForeColor = Color.FromArgb(203, 213, 225);
            }
            activeBtn = btn;
            activeBtn.BackColor = Color.FromArgb(37, 99, 235);
            activeBtn.ForeColor = Color.White;

            contentPanel.Controls.Clear();

            switch (name)
            {
                case "Overview": ShowOverview(); break;
                case "AvailableChallenges": ShowChallenges(); break;
                case "MySubmissions": ShowSubmissions(); break;
            }
        }

        // -----------------------------------------------
        // PAGE 1: Overview
        // -----------------------------------------------
        private void ShowOverview()
        {
            var welcome = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(contentPanel.ClientSize.Width - 60, 130),
                BackColor = Color.FromArgb(23, 47, 112),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            welcome.Controls.Add(new Label
            {
                Text = "Welcome, " + Session.DisplayName + "!",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                Location = new Point(30, 25),
                AutoSize = true
            });
            welcome.Controls.Add(new Label
            {
                Text = "Explore open challenges, form your team and submit your innovation.",
                ForeColor = Color.FromArgb(180, 200, 230),
                Font = new Font("Segoe UI", 10),
                Location = new Point(32, 75),
                AutoSize = true
            });
            contentPanel.Controls.Add(welcome);

            // Stats cards
            int y = 160;
            var card1 = MakeCard("My Submissions",
                CountQuery("SELECT COUNT(*) FROM SUBMISSION s JOIN PARTICIPATES_IN pi ON pi.TeamID=s.TeamID WHERE pi.ParticipantID=" + Session.LinkedID),
                Color.FromArgb(37, 99, 235));
            card1.Location = new Point(0, y);
            contentPanel.Controls.Add(card1);

            var card2 = MakeCard("Ongoing Challenges",
                CountQuery("SELECT COUNT(*) FROM CHALLENGE WHERE Status='Ongoing'"),
                Color.FromArgb(13, 148, 136));
            card2.Location = new Point(card1.Width + 20, y);
            contentPanel.Controls.Add(card2);

            var card3 = MakeCard("Upcoming Challenges",
                CountQuery("SELECT COUNT(*) FROM CHALLENGE WHERE Status='Upcoming'"),
                Color.FromArgb(234, 88, 12));
            card3.Location = new Point((card1.Width + 20) * 2, y);
            contentPanel.Controls.Add(card3);
        }

        private Panel MakeCard(string title, int value, Color accent)
        {
            var p = new Panel
            {
                Size = new Size(300, 120),
                BackColor = Color.White
            };
            p.Paint += (s, e) =>
            {
                e.Graphics.DrawRectangle(new Pen(Color.FromArgb(226, 232, 240)),
                    0, 0, p.Width - 1, p.Height - 1);
                e.Graphics.FillRectangle(new SolidBrush(accent), 0, 0, 6, p.Height);
            };
            p.Controls.Add(new Label
            {
                Text = value.ToString(),
                Font = new Font("Segoe UI", 30, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(25, 25),
                AutoSize = true
            });
            p.Controls.Add(new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(25, 78),
                AutoSize = true
            });
            return p;
        }

        private int CountQuery(string sql)
        {
            try { return Convert.ToInt32(Database.ExecuteScalar(sql)); }
            catch { return 0; }
        }

        // -----------------------------------------------
        // PAGE 2: Available Challenges
        // -----------------------------------------------
        private void ShowChallenges()
        {
            contentPanel.Controls.Add(new Label
            {
                Text = "Available Challenges",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(0, 0),
                AutoSize = true
            });

            var grid = MakeGrid();
            grid.Location = new Point(0, 50);
            grid.Size = new Size(contentPanel.ClientSize.Width - 60, contentPanel.ClientSize.Height - 100);
            grid.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            try
            {
                grid.DataSource = Database.ExecuteQuery(
                    @"SELECT ChallengeID    AS ""ID"",
                             Title          AS ""TITLE"",
                             TO_CHAR(StartDate,'YYYY-MM-DD') AS ""START DATE"",
                             TO_CHAR(EndDate,'YYYY-MM-DD')   AS ""END DATE"",
                             PrizePool      AS ""PRIZE POOL"",
                             Status         AS ""STATUS""
                      FROM CHALLENGE
                      WHERE Status IN ('Upcoming','Ongoing')
                      ORDER BY ChallengeID");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            contentPanel.Controls.Add(grid);
        }

        // -----------------------------------------------
        // PAGE 3: My Submissions
        // -----------------------------------------------
        private void ShowSubmissions()
        {
            contentPanel.Controls.Add(new Label
            {
                Text = "My Submissions",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(0, 0),
                AutoSize = true
            });

            var grid = MakeGrid();
            grid.Location = new Point(0, 50);
            grid.Size = new Size(contentPanel.ClientSize.Width - 60, contentPanel.ClientSize.Height - 100);
            grid.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            try
            {
                grid.DataSource = Database.ExecuteQuery(
                    @"SELECT s.SubmissionID    AS ""ID"",
                             s.SubmissionTitle AS ""TITLE"",
                             t.TeamName        AS ""TEAM"",
                             TO_CHAR(s.SubmissionDate,'YYYY-MM-DD') AS ""DATE"",
                             s.Status          AS ""STATUS""
                      FROM SUBMISSION s
                      JOIN PARTICIPATES_IN pi ON pi.TeamID = s.TeamID
                      LEFT JOIN TEAM t ON t.TeamID = s.TeamID
                      WHERE pi.ParticipantID = :pid
                      ORDER BY s.SubmissionID",
                    new OracleParameter("pid", Session.LinkedID));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            contentPanel.Controls.Add(grid);
        }

        private DataGridView MakeGrid()
        {
            var g = new DataGridView
            {
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = new Font("Segoe UI", 9),
                ColumnHeadersHeight = 42,
                EnableHeadersVisualStyles = false,
                GridColor = Color.FromArgb(226, 232, 240)
            };
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(71, 85, 105);
            g.RowTemplate.Height = 38;
            return g;
        }
    }
}