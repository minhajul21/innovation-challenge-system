﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class TeamsPanel : BaseDataPanel
    {
        public TeamsPanel()
            : base("Team Management",
                   "All teams currently registered across active innovation challenges.",
                   "+  Create Team")
        {
            actionBtn.Click += (s, e) => AddTeam();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT t.TeamID      AS ""TEAM ID"",
                             t.TeamName    AS ""TEAM NAME"",
                             NVL(t.TeamSize,0) AS ""TEAM SIZE"",
                             (SELECT COUNT(*) FROM PARTICIPATES_IN pi WHERE pi.TeamID=t.TeamID) AS ""MEMBERS""
                      FROM TEAM t ORDER BY t.TeamID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddTeam()
        {
            using (var dlg = new EntityDialog("Add Team", "Team Name", "Team Size"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        "INSERT INTO TEAM (TeamID, TeamName, TeamSize) VALUES (seq_team.NEXTVAL, :n, :s)",
                        new OracleParameter("n", dlg.Values["Team Name"]),
                        new OracleParameter("s", dlg.Values["Team Size"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["TEAM ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Team", "Team Name", "Team Size"))
            {
                dlg.SetValue("Team Name", row.Cells["TEAM NAME"].Value.ToString());
                dlg.SetValue("Team Size", row.Cells["TEAM SIZE"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        "UPDATE TEAM SET TeamName=:n, TeamSize=:s WHERE TeamID=:id",
                        new OracleParameter("n", dlg.Values["Team Name"]),
                        new OracleParameter("s", dlg.Values["Team Size"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["TEAM ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM TEAM WHERE TeamID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error (team may have references): " + ex.Message); }
        }
    }
}