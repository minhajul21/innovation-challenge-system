﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class EvaluationsPanel : BaseDataPanel
    {
        public EvaluationsPanel()
            : base("Project Evaluations",
                   "Score and review team submissions across every active challenge.",
                   "+  Add Evaluation")
        {
            actionBtn.Click += (s, e) => AddEvaluation();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT e.EvaluationID    AS ""EVAL ID"",
                             s.SubmissionTitle AS ""SUBMISSION"",
                             j.JudgeName       AS ""JUDGE"",
                             e.TotalScore      AS ""TOTAL SCORE"",
                             e.Comments        AS ""COMMENTS""
                      FROM EVALUATION e
                      LEFT JOIN SUBMISSION s ON e.SubmissionID = s.SubmissionID
                      LEFT JOIN JUDGE j ON e.JudgeID = j.JudgeID
                      ORDER BY e.EvaluationID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddEvaluation()
        {
            using (var dlg = new EntityDialog("Add Evaluation",
                "Judge ID", "Submission ID", "Total Score", "Comments"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    var v = dlg.Values;
                    Database.ExecuteNonQuery(
                        @"INSERT INTO EVALUATION
                          (EvaluationID, JudgeID, SubmissionID, TotalScore, Comments)
                          VALUES (seq_evaluation.NEXTVAL, :j, :s, :sc, :c)",
                        new OracleParameter("j", v["Judge ID"]),
                        new OracleParameter("s", v["Submission ID"]),
                        new OracleParameter("sc", v["Total Score"]),
                        new OracleParameter("c", v["Comments"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["EVAL ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Evaluation", "Total Score", "Comments"))
            {
                dlg.SetValue("Total Score", row.Cells["TOTAL SCORE"].Value.ToString());
                dlg.SetValue("Comments", row.Cells["COMMENTS"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"UPDATE EVALUATION SET TotalScore=:sc, Comments=:c
                          WHERE EvaluationID=:id",
                        new OracleParameter("sc", dlg.Values["Total Score"]),
                        new OracleParameter("c", dlg.Values["Comments"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["EVAL ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM EVALUATION WHERE EvaluationID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}