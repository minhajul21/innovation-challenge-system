﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public abstract class BaseDataPanel : UserControl
    {
        protected DataGridView grid;
        protected Panel headerPanel;
        protected Button actionBtn;

        protected BaseDataPanel(string title, string subtitle, string actionText = null)
        {
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20, 15, 20, 15);

            headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 90,
                BackColor = Color.Transparent
            };

            headerPanel.Controls.Add(new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(0, 0),
                AutoSize = true
            });
            headerPanel.Controls.Add(new Label
            {
                Text = subtitle,
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(2, 45),
                AutoSize = true
            });

            if (!string.IsNullOrEmpty(actionText))
            {
                actionBtn = new Button
                {
                    Text = actionText,
                    Size = new Size(190, 40),
                    BackColor = Color.FromArgb(37, 99, 235),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };
                actionBtn.FlatAppearance.BorderSize = 0;
                actionBtn.Location = new Point(headerPanel.Width - 210, 15);
                headerPanel.Resize += (s, e) =>
                    actionBtn.Location = new Point(headerPanel.Width - 210, 15);
                headerPanel.Controls.Add(actionBtn);
            }

            this.Controls.Add(headerPanel);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                Font = new Font("Segoe UI", 9),
                ColumnHeadersHeight = 42,
                EnableHeadersVisualStyles = false,
                GridColor = Color.FromArgb(226, 232, 240)
            };
            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(71, 85, 105);
            grid.RowTemplate.Height = 38;
            grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);

            // Auto-add Edit/Delete button columns after binding
            grid.DataBindingComplete += (s, e) =>
            {
                for (int i = grid.Columns.Count - 1; i >= 0; i--)
                {
                    if (grid.Columns[i].Name == "EditCol" || grid.Columns[i].Name == "DelCol")
                        grid.Columns.RemoveAt(i);
                }

                var editCol = new DataGridViewButtonColumn
                {
                    Name = "EditCol",
                    HeaderText = "EDIT",
                    Text = "Edit",
                    UseColumnTextForButtonValue = true,
                    Width = 70,
                    FlatStyle = FlatStyle.Flat,
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.None
                };
                editCol.DefaultCellStyle.BackColor = Color.FromArgb(241, 245, 249);
                editCol.DefaultCellStyle.ForeColor = Color.FromArgb(37, 99, 235);
                editCol.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);

                var delCol = new DataGridViewButtonColumn
                {
                    Name = "DelCol",
                    HeaderText = "DELETE",
                    Text = "Delete",
                    UseColumnTextForButtonValue = true,
                    Width = 80,
                    FlatStyle = FlatStyle.Flat,
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.None
                };
                delCol.DefaultCellStyle.BackColor = Color.FromArgb(254, 242, 242);
                delCol.DefaultCellStyle.ForeColor = Color.FromArgb(220, 38, 38);
                delCol.DefaultCellStyle.SelectionBackColor = Color.FromArgb(254, 226, 226);

                grid.Columns.Add(editCol);
                grid.Columns.Add(delCol);
            };

            grid.CellClick += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (grid.Columns[e.ColumnIndex].Name == "EditCol")
                    OnEdit(grid.Rows[e.RowIndex]);
                else if (grid.Columns[e.ColumnIndex].Name == "DelCol")
                {
                    if (MessageBox.Show("Are you sure you want to delete this record?",
                        "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        OnDelete(grid.Rows[e.RowIndex]);
                }
            };

            var spacer = new Panel { Dock = DockStyle.Top, Height = 12, BackColor = Color.Transparent };

            this.Controls.Add(grid);
            this.Controls.Add(spacer);

            this.Load += (s, e) => LoadData();
        }

        protected abstract void LoadData();
        protected virtual void OnEdit(DataGridViewRow row) { }
        protected virtual void OnDelete(DataGridViewRow row) { }
    }
}