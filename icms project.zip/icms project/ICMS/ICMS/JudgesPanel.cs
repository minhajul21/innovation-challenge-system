﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class JudgesPanel : BaseDataPanel
    {
        public JudgesPanel()
            : base("Judge Directory",
                   "All judges registered in ICMS with their areas of expertise.",
                   "+  Add Judge")
        {
            actionBtn.Click += (s, e) => AddJudge();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT JudgeID         AS ""JUDGE ID"",
                             JudgeName       AS ""JUDGE NAME"",
                             Email           AS ""EMAIL"",
                             AreaOfExpertise AS ""AREA OF EXPERTISE""
                      FROM JUDGE ORDER BY JudgeID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddJudge()
        {
            using (var dlg = new EntityDialog("Add Judge", "Judge Name", "Email", "Area of Expertise"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"INSERT INTO JUDGE (JudgeID, JudgeName, Email, AreaOfExpertise)
                          VALUES (seq_judge.NEXTVAL, :n, :e, :a)",
                        new OracleParameter("n", dlg.Values["Judge Name"]),
                        new OracleParameter("e", dlg.Values["Email"]),
                        new OracleParameter("a", dlg.Values["Area of Expertise"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["JUDGE ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Judge", "Judge Name", "Email", "Area of Expertise"))
            {
                dlg.SetValue("Judge Name", row.Cells["JUDGE NAME"].Value.ToString());
                dlg.SetValue("Email", row.Cells["EMAIL"].Value.ToString());
                dlg.SetValue("Area of Expertise", row.Cells["AREA OF EXPERTISE"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"UPDATE JUDGE SET JudgeName=:n, Email=:e, AreaOfExpertise=:a
                          WHERE JudgeID=:id",
                        new OracleParameter("n", dlg.Values["Judge Name"]),
                        new OracleParameter("e", dlg.Values["Email"]),
                        new OracleParameter("a", dlg.Values["Area of Expertise"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["JUDGE ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM JUDGE WHERE JudgeID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}