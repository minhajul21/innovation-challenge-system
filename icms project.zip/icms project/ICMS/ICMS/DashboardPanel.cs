﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class DashboardPanel : UserControl
    {
        public DashboardPanel()
        {
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.AutoScroll = true;
            BuildUI();
        }

        private void BuildUI()
        {
            var lblTitle = new Label
            {
                Text = "Dashboard",
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 20),
                AutoSize = true
            };
            var lblSub = new Label
            {
                Text = "Welcome back — here's what's happening across ICMS today.",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(22, 65),
                AutoSize = true
            };
            this.Controls.Add(lblTitle);
            this.Controls.Add(lblSub);

            string[][] cards = {
                new[] { "Total Challenges",   GetCount("CHALLENGE").ToString(),    "★" },
                new[] { "Total Participants", GetCount("PARTICIPANT").ToString(),  "☺" },
                new[] { "Total Teams",        GetCount("TEAM").ToString(),         "♟" },
                new[] { "Total Judges",       GetCount("JUDGE").ToString(),        "⚖" },
                new[] { "Total Submissions",  GetCount("SUBMISSION").ToString(),   "⇧" },
                new[] { "Total Awards",       GetCount("AWARD").ToString(),        "🏆" }
            };

            int x = 20, y = 110;
            int w = 230, h = 110, gap = 20;
            for (int i = 0; i < cards.Length; i++)
            {
                var card = CreateStatCard(cards[i][0], cards[i][1], cards[i][2]);
                card.Location = new Point(x, y);
                this.Controls.Add(card);
                x += w + gap;
                if ((i + 1) % 3 == 0) { x = 20; y += h + gap; }
            }

            // Overview
            var lblOverview = new Label
            {
                Text = "Challenge Status Overview",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, y + 20),
                AutoSize = true
            };
            this.Controls.Add(lblOverview);

            int completed = GetCountWhere("CHALLENGE", "Status='Completed'");
            int ongoing = GetCountWhere("CHALLENGE", "Status='Ongoing'");
            int upcoming = GetCountWhere("CHALLENGE", "Status='Upcoming'");

            var b1 = CreateStatusBar("Completed", completed, Color.FromArgb(37, 99, 235));
            b1.Location = new Point(20, y + 60);
            this.Controls.Add(b1);

            var b2 = CreateStatusBar("Ongoing", ongoing, Color.FromArgb(13, 148, 136));
            b2.Location = new Point(320, y + 60);
            this.Controls.Add(b2);

            var b3 = CreateStatusBar("Upcoming", upcoming, Color.FromArgb(234, 88, 12));
            b3.Location = new Point(620, y + 60);
            this.Controls.Add(b3);

            // Recent Activity
            var lblAct = new Label
            {
                Text = "Recent Activity",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, y + 190),
                AutoSize = true
            };
            this.Controls.Add(lblAct);

            var lst = new ListBox
            {
                Location = new Point(20, y + 230),
                Size = new Size(900, 180),
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White
            };
            lst.Items.AddRange(new object[] {
                "•  Eco Guardians submitted \"Smart Waste Management\" — 2 days ago",
                "•  Dr. Hasan Mahmud evaluated a submission — scored 89.50 — 3 days ago",
                "•  Smart City Makers joined Smart Dhaka Innovation Challenge — 5 days ago",
                "•  Award announced for AI for Social Good Challenge — 5 days ago",
                "•  Green Future Innovation Challenge opened for registration — 3 days ago"
            });
            this.Controls.Add(lst);
        }

        private Panel CreateStatCard(string title, string value, string icon)
        {
            var p = new Panel
            {
                Size = new Size(230, 110),
                BackColor = Color.White
            };
            p.Paint += (s, e) =>
            {
                e.Graphics.DrawRectangle(new Pen(Color.FromArgb(226, 232, 240)),
                    0, 0, p.Width - 1, p.Height - 1);
            };
            p.Controls.Add(new Label
            {
                Text = icon,
                Font = new Font("Segoe UI", 16),
                ForeColor = Color.FromArgb(37, 99, 235),
                Location = new Point(15, 12),
                AutoSize = true
            });
            p.Controls.Add(new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(55, 10),
                AutoSize = true
            });
            p.Controls.Add(new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(15, 70),
                AutoSize = true
            });
            return p;
        }

        private Panel CreateStatusBar(string label, int count, Color color)
        {
            var p = new Panel { Size = new Size(280, 100) };
            p.Controls.Add(new Label
            {
                Text = label + "  (" + count + ")",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(0, 0),
                AutoSize = true
            });
            var bar = new Panel
            {
                Location = new Point(0, 30),
                Size = new Size(Math.Max(30, count * 80), 45),
                BackColor = color
            };
            p.Controls.Add(bar);
            return p;
        }

        private int GetCount(string table)
        {
            try
            {
                var r = Database.ExecuteScalar("SELECT COUNT(*) FROM " + table);
                return Convert.ToInt32(r);
            }
            catch { return 0; }
        }

        private int GetCountWhere(string table, string where)
        {
            try
            {
                var r = Database.ExecuteScalar("SELECT COUNT(*) FROM " + table + " WHERE " + where);
                return Convert.ToInt32(r);
            }
            catch { return 0; }
        }
    }
}