﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class SubmissionsPanel : BaseDataPanel
    {
        public SubmissionsPanel()
            : base("Project Submissions",
                   "Track every team's innovation project and its review status.",
                   "+  Submit Project")
        {
            actionBtn.Click += (s, e) => AddSubmission();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT s.SubmissionID    AS ""SUBMISSION ID"",
                             s.SubmissionTitle AS ""PROJECT TITLE"",
                             t.TeamName        AS ""TEAM"",
                             TO_CHAR(s.SubmissionDate,'YYYY-MM-DD') AS ""SUBMISSION DATE"",
                             s.Status          AS ""STATUS""
                      FROM SUBMISSION s
                      LEFT JOIN TEAM t ON s.TeamID = t.TeamID
                      ORDER BY s.SubmissionID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddSubmission()
        {
            using (var dlg = new EntityDialog("Add Submission",
                "Project Title", "File Name", "Submission Date (YYYY-MM-DD)", "Status", "Team ID"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    var v = dlg.Values;
                    Database.ExecuteNonQuery(
                        @"INSERT INTO SUBMISSION
                          (SubmissionID, SubmissionTitle, FileName, SubmissionDate, Status, TeamID)
                          VALUES (seq_submission.NEXTVAL, :t, :f,
                                  TO_DATE(:d,'YYYY-MM-DD'), :s, :tid)",
                        new OracleParameter("t", v["Project Title"]),
                        new OracleParameter("f", v["File Name"]),
                        new OracleParameter("d", v["Submission Date (YYYY-MM-DD)"]),
                        new OracleParameter("s", v["Status"]),
                        new OracleParameter("tid", v["Team ID"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["SUBMISSION ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Submission",
                "Project Title", "Status"))
            {
                dlg.SetValue("Project Title", row.Cells["PROJECT TITLE"].Value.ToString());
                dlg.SetValue("Status", row.Cells["STATUS"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"UPDATE SUBMISSION SET SubmissionTitle=:t, Status=:s
                          WHERE SubmissionID=:id",
                        new OracleParameter("t", dlg.Values["Project Title"]),
                        new OracleParameter("s", dlg.Values["Status"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["SUBMISSION ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM SUBMISSION WHERE SubmissionID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}