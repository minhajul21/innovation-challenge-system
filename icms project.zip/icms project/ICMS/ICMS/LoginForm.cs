﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class LoginForm : Form
    {
        private TextBox txtEmail;
        private TextBox txtPassword;
        private ComboBox cboRole;

        public LoginForm()
        {
            this.Text = "ICMS - Login";
            this.Size = new Size(950, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            var left = new Panel
            {
                Dock = DockStyle.Left,
                Width = 420,
                BackColor = Color.FromArgb(23, 47, 112)
            };
            left.Controls.Add(new Label
            {
                Text = "Turning bold ideas into\nwinning innovation,\none challenge at a time.",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(40, 200),
                Size = new Size(360, 160)
            });
            left.Controls.Add(new Label
            {
                Text = "Innovation Challenge Management System",
                ForeColor = Color.FromArgb(148, 180, 230),
                Font = new Font("Segoe UI", 10),
                Location = new Point(40, 360),
                Size = new Size(360, 30)
            });
            left.Controls.Add(new Label
            {
                Text = "© 2026 ICMS · Academic Database Project",
                ForeColor = Color.FromArgb(100, 130, 180),
                Font = new Font("Segoe UI", 8),
                Location = new Point(40, 520),
                Size = new Size(360, 20)
            });

            var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };

            right.Controls.Add(new Label
            {
                Text = "Welcome Back",
                Font = new Font("Segoe UI", 26, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(60, 70),
                AutoSize = true
            });
            right.Controls.Add(new Label
            {
                Text = "Log in to manage challenges, teams, submissions and evaluations.",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(62, 120),
                Size = new Size(420, 40)
            });

            right.Controls.Add(new Label
            {
                Text = "Login as",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(60, 180),
                AutoSize = true
            });
            cboRole = new ComboBox
            {
                Location = new Point(60, 205),
                Width = 380,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 11)
            };
            cboRole.Items.AddRange(new object[] { "Administrator", "Participant", "Judge" });
            cboRole.SelectedIndex = 0;
            right.Controls.Add(cboRole);

            right.Controls.Add(new Label
            {
                Text = "Email Address",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(60, 255),
                AutoSize = true
            });
            txtEmail = new TextBox
            {
                Location = new Point(60, 280),
                Width = 380,
                Font = new Font("Segoe UI", 11),
                Text = "admin@icms-bd.org"
            };
            right.Controls.Add(txtEmail);

            right.Controls.Add(new Label
            {
                Text = "Password",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(60, 325),
                AutoSize = true
            });
            txtPassword = new TextBox
            {
                Location = new Point(60, 350),
                Width = 380,
                Font = new Font("Segoe UI", 11),
                UseSystemPasswordChar = true,
                Text = "admin123"
            };
            right.Controls.Add(txtPassword);

            var btnLogin = new Button
            {
                Text = "Login to ICMS",
                Location = new Point(60, 410),
                Width = 380,
                Height = 48,
                BackColor = Color.FromArgb(37, 99, 235),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;
            right.Controls.Add(btnLogin);

            var lblRegister = new Label
            {
                Text = "Do not have an account? Register",
                ForeColor = Color.FromArgb(37, 99, 235),
                Font = new Font("Segoe UI", 9, FontStyle.Underline),
                Location = new Point(165, 480),
                AutoSize = true,
                Cursor = Cursors.Hand
            };
            lblRegister.Click += (s, e) => { new RegisterForm().Show(); this.Hide(); };
            right.Controls.Add(lblRegister);

            this.Controls.Add(right);
            this.Controls.Add(left);
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string pwd = txtPassword.Text.Trim();
            string roleUI = cboRole.SelectedItem.ToString();
            string role = roleUI == "Administrator" ? "ADMIN"
                        : roleUI == "Participant" ? "PARTICIPANT" : "JUDGE";

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pwd))
            {
                MessageBox.Show("Please enter email and password.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Validate credentials against APP_USER
                var dt = Database.ExecuteQuery(
                    @"SELECT UserID, Email, Role, LinkedID
                      FROM APP_USER
                      WHERE Email = :e AND Password = :p AND Role = :r",
                    new OracleParameter("e", email),
                    new OracleParameter("p", pwd),
                    new OracleParameter("r", role));

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Invalid email / password, or wrong role selected.",
                        "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Populate session
                Session.UserID = Convert.ToInt32(dt.Rows[0]["USERID"]);
                Session.Email = dt.Rows[0]["EMAIL"].ToString();
                Session.Role = dt.Rows[0]["ROLE"].ToString();
                Session.LinkedID = dt.Rows[0]["LINKEDID"] == DBNull.Value
                    ? 0 : Convert.ToInt32(dt.Rows[0]["LINKEDID"]);

                // Get display name
                if (role == "ADMIN")
                    Session.DisplayName = "Administrator";
                else if (role == "PARTICIPANT")
                {
                    var n = Database.ExecuteScalar(
                        "SELECT ParticipantName FROM PARTICIPANT WHERE ParticipantID=:id",
                        new OracleParameter("id", Session.LinkedID));
                    Session.DisplayName = n?.ToString() ?? email;
                }
                else
                {
                    var n = Database.ExecuteScalar(
                        "SELECT JudgeName FROM JUDGE WHERE JudgeID=:id",
                        new OracleParameter("id", Session.LinkedID));
                    Session.DisplayName = n?.ToString() ?? email;
                }

                // Open appropriate dashboard
                Form target = null;
                if (role == "ADMIN") target = new MainForm();
                else if (role == "PARTICIPANT") target = new ParticipantForm();
                else target = new JudgeForm();

                this.Hide();
                target.FormClosed += (s2, args) =>
                {
                    Session.Clear();
                    this.Show();
                    txtPassword.Clear();
                };
                target.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error:\n\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}