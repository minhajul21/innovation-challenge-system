﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class ParticipantsPanel : BaseDataPanel
    {
        public ParticipantsPanel()
            : base("Participant Directory",
                   "Every participant registered across all ICMS challenges.",
                   "+  Add Participant")
        {
            actionBtn.Click += (s, e) => AddParticipant();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT ParticipantID   AS ""PARTICIPANT ID"",
                             ParticipantName AS ""NAME"",
                             Email           AS ""EMAIL"",
                             Country         AS ""COUNTRY""
                      FROM PARTICIPANT ORDER BY ParticipantID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddParticipant()
        {
            using (var dlg = new EntityDialog("Add Participant", "Name", "Email", "Country"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"INSERT INTO PARTICIPANT (ParticipantID, ParticipantName, Email, Country)
                          VALUES (seq_participant.NEXTVAL, :n, :e, :c)",
                        new OracleParameter("n", dlg.Values["Name"]),
                        new OracleParameter("e", dlg.Values["Email"]),
                        new OracleParameter("c", dlg.Values["Country"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["PARTICIPANT ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Participant", "Name", "Email", "Country"))
            {
                dlg.SetValue("Name", row.Cells["NAME"].Value.ToString());
                dlg.SetValue("Email", row.Cells["EMAIL"].Value.ToString());
                dlg.SetValue("Country", row.Cells["COUNTRY"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"UPDATE PARTICIPANT SET ParticipantName=:n, Email=:e, Country=:c
                          WHERE ParticipantID=:id",
                        new OracleParameter("n", dlg.Values["Name"]),
                        new OracleParameter("e", dlg.Values["Email"]),
                        new OracleParameter("c", dlg.Values["Country"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["PARTICIPANT ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM PARTICIPANT WHERE ParticipantID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}