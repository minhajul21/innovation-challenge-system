﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class MainForm : Form
    {
        private Panel contentPanel;
        private Panel sidebar;
        private Button activeBtn;

        public MainForm()
        {
            this.Text = "ICMS Admin";
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.MinimumSize = new Size(1200, 720);

            // SIDEBAR
            sidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 240,
                BackColor = Color.FromArgb(15, 23, 42)
            };
            sidebar.Controls.Add(new Label
            {
                Text = "◈  ICMS\n     Admin",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 15, FontStyle.Bold),
                Location = new Point(20, 25),
                Size = new Size(200, 70)
            });

            string[] items = { "Dashboard", "Challenges", "Teams", "Participants",
                               "Judges", "Submissions", "Evaluations", "Awards" };
            string[] icons = { "▦", "★", "♟", "☺", "⚖", "⇧", "✓", "🏆" };

            int y = 130;
            for (int i = 0; i < items.Length; i++)
            {
                var btn = new Button
                {
                    Name = "btn" + items[i],
                    Text = "   " + icons[i] + "   " + items[i],
                    Location = new Point(0, y),
                    Size = new Size(240, 45),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(15, 23, 42),
                    ForeColor = Color.FromArgb(203, 213, 225),
                    Font = new Font("Segoe UI", 10),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Cursor = Cursors.Hand
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 41, 59);
                btn.Click += SidebarBtn_Click;
                sidebar.Controls.Add(btn);
                y += 48;
            }

            // TOP BAR
            var topBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = Color.White
            };
            var txtSearch = new TextBox
            {
                Location = new Point(25, 20),
                Width = 500,
                Font = new Font("Segoe UI", 11),
                Text = "Search challenges, teams, submissions...",
                ForeColor = Color.Gray,
                BorderStyle = BorderStyle.None
            };
            topBar.Controls.Add(txtSearch);

            var lblUser = new Label
            {
                Text = "AD      ICMS Admin\n            Administrator",
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleRight,
                Location = new Point(topBar.Width - 400, 12),
                Size = new Size(200, 40),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                ForeColor = Color.FromArgb(30, 41, 59)
            };
            topBar.Controls.Add(lblUser);

            var btnLogout = new Button
            {
                Text = "Logout",
                Size = new Size(100, 38),
                Location = new Point(topBar.Width - 130, 13),
                BackColor = Color.FromArgb(254, 242, 242),
                ForeColor = Color.FromArgb(220, 38, 38),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += (s, e) =>
            {
                if (MessageBox.Show("Are you sure you want to log out?", "Logout",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    this.Close();
                }
            };
            topBar.Controls.Add(btnLogout);

            // CONTENT
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                BackColor = Color.FromArgb(241, 245, 249),
                AutoScroll = true
            };

            this.Controls.Add(contentPanel);
            this.Controls.Add(topBar);
            this.Controls.Add(sidebar);

            this.Load += (s, e) =>
            {
                var btn = (Button)sidebar.Controls["btnDashboard"];
                SidebarBtn_Click(btn, EventArgs.Empty);
            };
        }

        private void SidebarBtn_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            string name = btn.Name.Substring(3);
            UserControl panel = null;

            switch (name)
            {
                case "Dashboard": panel = new DashboardPanel(); break;
                case "Challenges": panel = new ChallengesPanel(); break;
                case "Teams": panel = new TeamsPanel(); break;
                case "Participants": panel = new ParticipantsPanel(); break;
                case "Judges": panel = new JudgesPanel(); break;
                case "Submissions": panel = new SubmissionsPanel(); break;
                case "Evaluations": panel = new EvaluationsPanel(); break;
                case "Awards": panel = new AwardsPanel(); break;
            }
            if (panel == null) return;

            contentPanel.Controls.Clear();
            panel.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(panel);

            if (activeBtn != null)
            {
                activeBtn.BackColor = Color.FromArgb(15, 23, 42);
                activeBtn.ForeColor = Color.FromArgb(203, 213, 225);
            }
            activeBtn = btn;
            activeBtn.BackColor = Color.FromArgb(37, 99, 235);
            activeBtn.ForeColor = Color.White;
        }
    }
}