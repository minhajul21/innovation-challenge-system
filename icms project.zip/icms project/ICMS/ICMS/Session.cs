﻿namespace ICMS
{
    // Stores the currently logged-in user information
    public static class Session
    {
        public static int UserID { get; set; }
        public static string Email { get; set; }
        public static string Role { get; set; }   // ADMIN / PARTICIPANT / JUDGE
        public static int LinkedID { get; set; }  // ParticipantID or JudgeID
        public static string DisplayName { get; set; }

        public static void Clear()
        {
            UserID = 0;
            Email = null;
            Role = null;
            LinkedID = 0;
            DisplayName = null;
        }
    }
}