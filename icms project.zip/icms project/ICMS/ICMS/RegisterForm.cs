﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class RegisterForm : Form
    {
        private TextBox txtName, txtEmail, txtPassword, txtConfirm, txtCountry;
        private ComboBox cboRole;

        public RegisterForm()
        {
            this.Text = "ICMS - Register";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            // LEFT PANEL
            var left = new Panel
            {
                Dock = DockStyle.Left,
                Width = 420,
                BackColor = Color.FromArgb(23, 47, 112)
            };
            left.Controls.Add(new Label
            {
                Text = "Join ICMS\nand turn bold\nideas into impact.",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                Location = new Point(40, 220),
                Size = new Size(360, 160)
            });
            left.Controls.Add(new Label
            {
                Text = "Register to participate in innovation challenges\nas a participant or a judge.",
                ForeColor = Color.FromArgb(148, 180, 230),
                Font = new Font("Segoe UI", 10),
                Location = new Point(40, 400),
                Size = new Size(360, 60)
            });
            left.Controls.Add(new Label
            {
                Text = "© 2026 ICMS · Academic Database Project",
                ForeColor = Color.FromArgb(100, 130, 180),
                Font = new Font("Segoe UI", 8),
                Location = new Point(40, 620),
                Size = new Size(360, 20)
            });

            // RIGHT PANEL
            var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };

            right.Controls.Add(new Label
            {
                Text = "Create Account",
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(60, 40),
                AutoSize = true
            });
            right.Controls.Add(new Label
            {
                Text = "Fill in the details below to register.",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(62, 82),
                AutoSize = true
            });

            // Register as
            right.Controls.Add(MakeLabel("Register as", 60, 125));
            cboRole = new ComboBox
            {
                Location = new Point(60, 150),
                Width = 420,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 11)
            };
            cboRole.Items.AddRange(new object[] { "Participant", "Judge" });
            cboRole.SelectedIndex = 0;
            right.Controls.Add(cboRole);

            // Name
            right.Controls.Add(MakeLabel("Full Name", 60, 195));
            txtName = MakeText(60, 220, 420);
            right.Controls.Add(txtName);

            // Email
            right.Controls.Add(MakeLabel("Email Address", 60, 265));
            txtEmail = MakeText(60, 290, 420);
            right.Controls.Add(txtEmail);

            // Country
            right.Controls.Add(MakeLabel("Country", 60, 335));
            txtCountry = MakeText(60, 360, 420);
            txtCountry.Text = "Bangladesh";
            right.Controls.Add(txtCountry);

            // Password
            right.Controls.Add(MakeLabel("Password", 60, 405));
            txtPassword = MakeText(60, 430, 200);
            txtPassword.UseSystemPasswordChar = true;
            right.Controls.Add(txtPassword);

            // Confirm Password
            right.Controls.Add(MakeLabel("Confirm Password", 280, 405));
            txtConfirm = MakeText(280, 430, 200);
            txtConfirm.UseSystemPasswordChar = true;
            right.Controls.Add(txtConfirm);

            // Register Button
            var btnReg = new Button
            {
                Text = "Register",
                Location = new Point(60, 490),
                Width = 420,
                Height = 48,
                BackColor = Color.FromArgb(37, 99, 235),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnReg.FlatAppearance.BorderSize = 0;
            btnReg.Click += BtnReg_Click;
            right.Controls.Add(btnReg);

            var lblBack = new Label
            {
                Text = "Already have an account? Login",
                ForeColor = Color.FromArgb(37, 99, 235),
                Font = new Font("Segoe UI", 9, FontStyle.Underline),
                Location = new Point(185, 555),
                AutoSize = true,
                Cursor = Cursors.Hand
            };
            lblBack.Click += (s, e) => { new LoginForm().Show(); this.Close(); };
            right.Controls.Add(lblBack);

            this.Controls.Add(right);
            this.Controls.Add(left);
        }

        private Label MakeLabel(string text, int x, int y) => new Label
        {
            Text = text,
            Location = new Point(x, y),
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            AutoSize = true
        };

        private TextBox MakeText(int x, int y, int w) => new TextBox
        {
            Location = new Point(x, y),
            Width = w,
            Font = new Font("Segoe UI", 11)
        };

        private void BtnReg_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtPassword.Text != txtConfirm.Text)
            {
                MessageBox.Show("Passwords do not match.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string role = cboRole.SelectedItem.ToString();
                string email = txtEmail.Text.Trim();
                string pwd = txtPassword.Text.Trim();

                // Check duplicate in APP_USER
                var exist = Database.ExecuteScalar(
                    "SELECT COUNT(*) FROM APP_USER WHERE Email=:e",
                    new OracleParameter("e", email));
                if (Convert.ToInt32(exist) > 0)
                {
                    MessageBox.Show("This email is already registered. Try logging in.",
                        "Duplicate Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int linkedID = 0;

                if (role == "Participant")
                {
                    // Insert into PARTICIPANT
                    Database.ExecuteNonQuery(
                        @"INSERT INTO PARTICIPANT (ParticipantID, ParticipantName, Email, Country)
                          VALUES (seq_participant.NEXTVAL, :n, :e, :c)",
                        new OracleParameter("n", txtName.Text.Trim()),
                        new OracleParameter("e", email),
                        new OracleParameter("c", txtCountry.Text.Trim()));

                    // Retrieve the ID just inserted
                    var idObj = Database.ExecuteScalar(
                        "SELECT ParticipantID FROM PARTICIPANT WHERE Email=:e",
                        new OracleParameter("e", email));
                    linkedID = Convert.ToInt32(idObj);

                    // Insert into APP_USER
                    Database.ExecuteNonQuery(
                        @"INSERT INTO APP_USER (UserID, Email, Password, Role, LinkedID)
                          VALUES (seq_app_user.NEXTVAL, :e, :p, 'PARTICIPANT', :l)",
                        new OracleParameter("e", email),
                        new OracleParameter("p", pwd),
                        new OracleParameter("l", linkedID));
                }
                else // Judge
                {
                    Database.ExecuteNonQuery(
                        @"INSERT INTO JUDGE (JudgeID, JudgeName, Email, AreaOfExpertise)
                          VALUES (seq_judge.NEXTVAL, :n, :e, :a)",
                        new OracleParameter("n", txtName.Text.Trim()),
                        new OracleParameter("e", email),
                        new OracleParameter("a", "General"));

                    var idObj = Database.ExecuteScalar(
                        "SELECT JudgeID FROM JUDGE WHERE Email=:e",
                        new OracleParameter("e", email));
                    linkedID = Convert.ToInt32(idObj);

                    Database.ExecuteNonQuery(
                        @"INSERT INTO APP_USER (UserID, Email, Password, Role, LinkedID)
                          VALUES (seq_app_user.NEXTVAL, :e, :p, 'JUDGE', :l)",
                        new OracleParameter("e", email),
                        new OracleParameter("p", pwd),
                        new OracleParameter("l", linkedID));
                }

                MessageBox.Show("Registration successful!\nYou can now log in.",
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                new LoginForm().Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration failed:\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}