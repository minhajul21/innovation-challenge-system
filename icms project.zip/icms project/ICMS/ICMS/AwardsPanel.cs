﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class AwardsPanel : BaseDataPanel
    {
        public AwardsPanel()
            : base("Challenge Awards",
                   "Celebrating the winning teams of the Innovation Challenge Management System.",
                   "+  Add Award")
        {
            actionBtn.Click += (s, e) => AddAward();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT a.AwardID          AS ""AWARD ID"",
                             a.AwardRank        AS ""RANK"",
                             a.PrizeAmount      AS ""PRIZE AMOUNT"",
                             TO_CHAR(a.AnnouncementDate,'YYYY-MM-DD') AS ""ANNOUNCED ON"",
                             c.Title            AS ""CHALLENGE"",
                             t.TeamName         AS ""WINNING TEAM""
                      FROM AWARD a
                      LEFT JOIN CHALLENGE c ON a.ChallengeID = c.ChallengeID
                      LEFT JOIN TEAM t ON a.TeamID = t.TeamID
                      ORDER BY a.AwardID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddAward()
        {
            using (var dlg = new EntityDialog("Add Award",
                "Rank", "Prize Amount", "Announcement Date (YYYY-MM-DD)",
                "Challenge ID", "Team ID"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    var v = dlg.Values;
                    Database.ExecuteNonQuery(
                        @"INSERT INTO AWARD
                          (AwardID, AwardRank, PrizeAmount, AnnouncementDate, ChallengeID, TeamID)
                          VALUES (seq_award.NEXTVAL, :r, :p,
                                  TO_DATE(:d,'YYYY-MM-DD'), :c, :t)",
                        new OracleParameter("r", v["Rank"]),
                        new OracleParameter("p", v["Prize Amount"]),
                        new OracleParameter("d", v["Announcement Date (YYYY-MM-DD)"]),
                        new OracleParameter("c", v["Challenge ID"]),
                        new OracleParameter("t", v["Team ID"]));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["AWARD ID"].Value.ToString();
            using (var dlg = new EntityDialog("Edit Award", "Rank", "Prize Amount"))
            {
                dlg.SetValue("Rank", row.Cells["RANK"].Value.ToString());
                dlg.SetValue("Prize Amount", row.Cells["PRIZE AMOUNT"].Value.ToString());
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Database.ExecuteNonQuery(
                        @"UPDATE AWARD SET AwardRank=:r, PrizeAmount=:p
                          WHERE AwardID=:id",
                        new OracleParameter("r", dlg.Values["Rank"]),
                        new OracleParameter("p", dlg.Values["Prize Amount"]),
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["AWARD ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM AWARD WHERE AwardID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}