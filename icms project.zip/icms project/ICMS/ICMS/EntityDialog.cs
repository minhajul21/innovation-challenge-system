﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ICMS
{
    public class EntityDialog : Form
    {
        private Dictionary<string, TextBox> fields = new Dictionary<string, TextBox>();
        public Dictionary<string, string> Values { get; private set; }
        public bool IsEdit { get; set; } = false;

        public EntityDialog(string title, params string[] fieldNames)
        {
            this.Text = title;
            this.Size = new Size(480, 130 + fieldNames.Length * 55);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;
            this.Font = new Font("Segoe UI", 10);

            int y = 20;
            foreach (var name in fieldNames)
            {
                var lbl = new Label
                {
                    Text = name,
                    Location = new Point(20, y),
                    Width = 140,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    ForeColor = Color.FromArgb(30, 41, 59)
                };
                var txt = new TextBox
                {
                    Location = new Point(170, y - 3),
                    Width = 270,
                    Font = new Font("Segoe UI", 10),
                    Name = "txt_" + name
                };
                this.Controls.Add(lbl);
                this.Controls.Add(txt);
                fields[name] = txt;
                y += 50;
            }

            var btnOk = new Button
            {
                Text = "Save",
                DialogResult = DialogResult.OK,
                Location = new Point(170, y + 10),
                Width = 130,
                Height = 40,
                BackColor = Color.FromArgb(37, 99, 235),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnOk.FlatAppearance.BorderSize = 0;

            var btnCancel = new Button
            {
                Text = "Cancel",
                DialogResult = DialogResult.Cancel,
                Location = new Point(310, y + 10),
                Width = 130,
                Height = 40,
                Font = new Font("Segoe UI", 10),
                Cursor = Cursors.Hand
            };

            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;

            this.FormClosing += (s, e) =>
            {
                if (this.DialogResult == DialogResult.OK)
                {
                    Values = new Dictionary<string, string>();
                    foreach (var kv in fields) Values[kv.Key] = kv.Value.Text;
                }
            };
        }

        public void SetValue(string field, string value)
        {
            if (fields.ContainsKey(field)) fields[field].Text = value;
        }
    }
}
