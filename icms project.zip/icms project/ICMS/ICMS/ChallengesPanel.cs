﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ICMS
{
    public class ChallengesPanel : BaseDataPanel
    {
        public ChallengesPanel()
            : base("Challenge Management",
                   "Create, review, and manage every innovation challenge on ICMS.",
                   "+  Add Challenge")
        {
            actionBtn.Click += (s, e) => AddChallenge();
        }

        protected override void LoadData()
        {
            try
            {
                var dt = Database.ExecuteQuery(
                    @"SELECT c.ChallengeID    AS ""CHALLENGE ID"",
                             c.Title          AS ""TITLE"",
                             cat.CategoryName AS ""CATEGORY"",
                             TO_CHAR(c.StartDate,'YYYY-MM-DD') AS ""START DATE"",
                             TO_CHAR(c.EndDate,'YYYY-MM-DD')   AS ""END DATE"",
                             c.PrizePool      AS ""PRIZE POOL"",
                             c.Status         AS ""STATUS""
                      FROM CHALLENGE c
                      JOIN CATEGORY cat ON c.CategoryID = cat.CategoryID
                      ORDER BY c.ChallengeID");
                grid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void AddChallenge()
        {
            using (var dlg = new EntityDialog("Add Challenge",
                "Title", "Start Date (YYYY-MM-DD)", "End Date (YYYY-MM-DD)",
                "Prize Pool", "Status"))
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    var v = dlg.Values;
                    Database.ExecuteNonQuery(
                        @"INSERT INTO CHALLENGE
                          (ChallengeID, Title, StartDate, EndDate, PrizePool, Status, OrganizerID, CategoryID)
                          VALUES (seq_challenge.NEXTVAL, :t,
                                  TO_DATE(:s,'YYYY-MM-DD'), TO_DATE(:e,'YYYY-MM-DD'),
                                  :p, :st, 1, 1)",
                        new OracleParameter("t", v["Title"]),
                        new OracleParameter("s", v["Start Date (YYYY-MM-DD)"]),
                        new OracleParameter("e", v["End Date (YYYY-MM-DD)"]),
                        new OracleParameter("p", v["Prize Pool"]),
                        new OracleParameter("st", v["Status"]));
                    LoadData();
                    MessageBox.Show("Challenge added successfully!");
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnEdit(DataGridViewRow row)
        {
            string id = row.Cells["CHALLENGE ID"].Value.ToString();

            // Fetch existing OrganizerID & CategoryID from DB
            int orgID = 1, catID = 1;
            try
            {
                var dt = Database.ExecuteQuery(
                    "SELECT OrganizerID, CategoryID FROM CHALLENGE WHERE ChallengeID=:id",
                    new OracleParameter("id", id));
                if (dt.Rows.Count > 0)
                {
                    orgID = Convert.ToInt32(dt.Rows[0]["ORGANIZERID"]);
                    catID = Convert.ToInt32(dt.Rows[0]["CATEGORYID"]);
                }
            }
            catch { }

            using (var dlg = new EntityDialog("Edit Challenge",
                "Title", "Start Date (YYYY-MM-DD)", "End Date (YYYY-MM-DD)",
                "Prize Pool", "Status"))
            {
                dlg.SetValue("Title", row.Cells["TITLE"].Value.ToString());
                dlg.SetValue("Start Date (YYYY-MM-DD)", row.Cells["START DATE"].Value.ToString());
                dlg.SetValue("End Date (YYYY-MM-DD)", row.Cells["END DATE"].Value.ToString());
                dlg.SetValue("Prize Pool", row.Cells["PRIZE POOL"].Value.ToString());
                dlg.SetValue("Status", row.Cells["STATUS"].Value.ToString());

                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    var v = dlg.Values;
                    Database.ExecuteNonQuery(
                        @"UPDATE CHALLENGE SET Title=:t,
                            StartDate=TO_DATE(:s,'YYYY-MM-DD'),
                            EndDate=TO_DATE(:e,'YYYY-MM-DD'),
                            PrizePool=:p, Status=:st,
                            OrganizerID=:o, CategoryID=:c
                          WHERE ChallengeID=:id",
                        new OracleParameter("t", v["Title"]),
                        new OracleParameter("s", v["Start Date (YYYY-MM-DD)"]),
                        new OracleParameter("e", v["End Date (YYYY-MM-DD)"]),
                        new OracleParameter("p", v["Prize Pool"]),
                        new OracleParameter("st", v["Status"]),
                        new OracleParameter("o", orgID),   // ← existing value
                        new OracleParameter("c", catID),   // ← existing value
                        new OracleParameter("id", id));
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        protected override void OnDelete(DataGridViewRow row)
        {
            string id = row.Cells["CHALLENGE ID"].Value.ToString();
            try
            {
                Database.ExecuteNonQuery("DELETE FROM CHALLENGE WHERE ChallengeID=:id",
                    new OracleParameter("id", id));
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}